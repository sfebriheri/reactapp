# REACT FIREBASE ADMIN
## V5.2.0

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).
For project instalation videos and docuemtnation go [here](http://fireadmin.mobidonia.com/).
